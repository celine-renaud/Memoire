import syntaxgym

syntaxgym.compute_surprisals("LSTM", "ORC_CMP.json")